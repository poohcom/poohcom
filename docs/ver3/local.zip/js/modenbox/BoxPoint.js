var BoxPoint = (function () {
    function BoxPoint(x, y) {
        this.x = 0.0;
        this.y = 0.0;
        this.x = x;
        this.y = y;
    }
    return BoxPoint;
}());
// 1,1 정규화된 점  
//# sourceMappingURL=BoxPoint.js.map