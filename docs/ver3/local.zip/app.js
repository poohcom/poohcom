window.onload = function () {
    SceneManager.instance().init();
};
//# sourceMappingURL=app.js.map