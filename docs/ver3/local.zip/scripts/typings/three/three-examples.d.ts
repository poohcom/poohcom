// Things from three.js/examples/ that do not (yet) have their own file

import {EventDispatcher, Shader} from "./three-core";

export var AWDLoader: any;
export var OBJLoader2: any;
export var STLLoader: any;
export var FlyControls: any;
export var BloomPass: any;
export var DotScreenShader: Shader;
export var RGBShiftShader: Shader;
export var FXAAShader: Shader;
