import { Shader } from "./three-core";
export var CopyShader: Shader;
